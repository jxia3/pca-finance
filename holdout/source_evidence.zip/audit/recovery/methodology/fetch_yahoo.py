from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import json
from pathlib import Path
import urllib.parse
import urllib.request
import pandas as pd

ROOT = Path(__file__).resolve().parent

def fetch(symbol: str) -> dict:
    filename = ROOT / "yahoo" / f"{symbol}.json"
    if filename.exists():
        return {"symbol": symbol, "cached": True}
    yahoo_symbol = symbol.replace(".", "-")
    start = int(datetime(2022, 1, 1, tzinfo=timezone.utc).timestamp())
    end = int(datetime(2026, 11, 18, tzinfo=timezone.utc).timestamp())
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(yahoo_symbol)}?period1={start}&period2={end}&interval=1d&events=div%2Csplits"
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(request, timeout=40) as response:
            contents = response.read()
        parsed = json.loads(contents)
        if not parsed.get("chart", {}).get("result"):
            raise ValueError("No chart results")
        filename.write_bytes(contents)
        return {"symbol": symbol, "url": url, "bytes": len(contents), "retrieved_utc": datetime.now(timezone.utc).isoformat()}
    except Exception as error:
        return {"symbol": symbol, "url": url, "error": str(error)}

def main() -> None:
    (ROOT / "yahoo").mkdir(exist_ok=True)
    report = pd.read_csv(ROOT / "bulk_screen.csv")
    symbols = set(report.loc[report.last_price.ge("2026-11-10"), "ticker"])
    symbols.update(["CYAN", "DXYN", "BPPTU", "PTNT", "PTNTD", "SALMZ", "TUPBQ", "SGMA", "DYNT", "SUP", "ALOT", "AVB"])
    with ThreadPoolExecutor(max_workers=4) as executor:
        results = list(executor.map(fetch, sorted(symbols)))
    (ROOT / "yahoo_manifest.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(json.dumps({"requests": len(results), "errors": [row for row in results if "error" in row]}, indent=2))

if __name__ == "__main__":
    main()
