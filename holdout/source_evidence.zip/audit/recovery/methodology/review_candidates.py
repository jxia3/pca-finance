import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent

def read_table(symbol: str) -> pd.DataFrame:
    frame = pd.read_csv(ROOT / "tables" / f"{symbol}.csv", dtype=str)
    frame["date"] = pd.to_datetime(frame.date.str.extract(r"(^[A-Za-z]{3} \d{1,2}, \d{4})")[0], format="%b %d, %Y").dt.strftime("%Y-%m-%d")
    for column in ["open", "high", "low", "close", "adjusted_close"]:
        frame[column] = pd.to_numeric(frame[column].str.replace(",", ""), errors="raise")
    return frame.set_index("date").sort_index()

def main() -> None:
    checks = pd.read_csv(ROOT / "large_move_checks.csv", dtype={"permno": str})
    prices = pd.concat([pd.read_parquet(ROOT / "dolt_ohlcv.parquet"), pd.read_parquet(ROOT / "dolt_tail.parquet")]).drop_duplicates(["date", "act_symbol"])
    for index, row in checks.iterrows():
        dolt = prices.loc[prices.act_symbol.eq(row.ticker)].set_index("date").close.astype(float).sort_index().loc[:row.date].tail(2)
        yahoo_path = ROOT / "yahoo" / f"{row.ticker}.json"
        if yahoo_path.exists():
            result = json.loads(yahoo_path.read_bytes())["chart"]["result"][0]
            dates = pd.to_datetime(result["timestamp"], unit="s", utc=True).tz_convert("America/New_York").strftime("%Y-%m-%d")
            other = pd.Series(result["indicators"]["quote"][0]["close"], index=dates, dtype=float)
            if row.ticker == "PTN":
                other = other / 50
            source = f"yahoo/{row.ticker}.json"
        else:
            other = read_table(row.ticker).close
            source = f"tables/{row.ticker}.csv"
        observed = other.reindex(dolt.index)
        error = (dolt - observed).abs()
        checks.loc[index, "price_pairs"] = int(observed.notna().sum())
        checks.loc[index, "max_price_difference"] = error.max()
        checks.loc[index, "corroboration_source"] = source
        checks.loc[index, "accepted"] = bool(observed.notna().all() and error.max() <= 0.00501)
    checks.to_csv(ROOT / "large_move_checks.csv", index=False)
    print(checks[["ticker", "date", "price_pairs", "max_price_difference", "accepted"]].to_string(index=False))

if __name__ == "__main__":
    main()
