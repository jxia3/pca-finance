import io
import json
from pathlib import Path
import zipfile
import numpy as np
import pandas as pd
from screen_bulk import metrics

ROOT = Path(__file__).resolve().parent

def main() -> None:
    original = pd.read_csv(ROOT / "archive/baseline/holdout_daily_returns.csv", index_col="date")
    returns = original.copy()
    mapping = pd.read_csv(ROOT.parent / "holdout/holdout_tickers.csv", dtype=str).set_index("stock_id")
    report = pd.read_csv(ROOT / "bulk_screen.csv", dtype={"permno": str})
    candidates = pd.read_parquet(ROOT / "bulk_candidates.parquet")
    large = pd.read_csv(ROOT / "large_move_checks.csv", dtype={"permno": str})
    with zipfile.ZipFile(ROOT / "archive/baseline/source_evidence.zip") as archive:
        cutoffs = pd.read_csv(io.BytesIO(archive.read("audit/reviewed_security_cutoffs.csv")), dtype=str)
        codes = pd.read_parquet(io.BytesIO(archive.read("audit/extension_source_codes.parquet")))
    cutoffs = pd.concat([cutoffs, pd.read_csv(ROOT / "reviewed_cutoffs.csv", dtype=str)], ignore_index=True)
    assert cutoffs.permno.is_unique
    assert all(mapping.loc[row.permno, "ticker"] == row.ticker for row in cutoffs.itertuples())
    changes = []
    for row in cutoffs.itertuples():
        mask = (returns.index >= row.exclude_from) & returns[row.permno].notna()
        for date in returns.index[mask]:
            changes.append({"permno": row.permno, "ticker": row.ticker, "date": date, "previous_return": returns.loc[date, row.permno], "change": "removed_after_documented_cutoff", "source": row.source})
        returns.loc[returns.index >= row.exclude_from, row.permno] = np.nan
        codes.loc[codes.index >= row.exclude_from, row.permno] = 0
    additions = []

    def add(identifier: str, candidate: pd.Series, code: int, source: str) -> None:
        candidate = candidate.reindex(returns.index).copy()
        cutoff = cutoffs.loc[cutoffs.permno.eq(identifier)]
        if not cutoff.empty:
            candidate.loc[candidate.index >= cutoff.iloc[0].exclude_from] = np.nan
        mask = returns[identifier].isna() & candidate.notna()
        returns.loc[mask, identifier] = candidate[mask]
        codes.loc[mask, identifier] = code
        if mask.any():
            additions.append({"permno": identifier, "ticker": mapping.loc[identifier, "ticker"], "source": source, "added": int(mask.sum())})

    for row in report.itertuples():
        accepted = row.status == "pass"
        if row.permno == "15537":
            # Reviewed ALOT exception: all 488 original pairs agree within
            # 0.000001; the later vendor bridge differs by at most seven bp.
            accepted = row.pairs >= 488 and row.max_error < 0.000001 and row.bridge_pairs >= 545 and row.bridge_max_error < 0.0007 and row.unreviewed_splits == 0
        if row.status == "large_return_review":
            reviewed = large.loc[large.permno.eq(row.permno)]
            accepted = not reviewed.empty and reviewed.accepted.all() and row.pairs >= 100 and row.correlation >= 0.995 and row.within_5bp >= 0.95 and row.bridge_max_error <= 0.0005 and row.unreviewed_splits == 0
        if accepted:
            add(row.permno, candidates[row.permno], 8, "dolt_bulk_recovery")
    latest = pd.read_csv(ROOT / "latest_checks.csv", dtype={"permno": str})
    for row in latest.loc[latest.accepted].itertuples():
        add(row.permno, pd.Series({"2026-11-17": row.latest_return}), 9, "yahoo_close_with_dolt_previous_close")
    yahoo = pd.read_parquet(ROOT / "yahoo_candidates.parquet")
    yahoo_report = []
    for row in latest.itertuples():
        candidate = yahoo[row.permno].reindex(returns.index)
        bridge = metrics(returns[row.permno], candidate)
        accepted = row.pairs >= 100 and row.correlation >= 0.995 and row.within_5bp >= 0.95 and bridge["pairs"] >= 100 and bridge["max_error"] <= 0.0005
        if accepted:
            add(row.permno, candidate, 10, "yahoo_adjusted_close_overlap_validated")
        yahoo_report.append({"permno": row.permno, "ticker": row.ticker, "accepted": accepted, **bridge})
    actions = pd.read_parquet(ROOT / "action_candidates.parquet")
    for identifier in actions:
        add(identifier, actions[identifier], 11, "documented_action_and_corroborated_prices")
    otc = pd.read_parquet(ROOT / "otc_candidates.parquet")
    for identifier in otc:
        add(identifier, otc[identifier], 12, "corroborated_otc_prices_rounding_exception")
    tables = pd.read_parquet(ROOT / "otc_table_candidates.parquet")
    for identifier in tables:
        add(identifier, tables[identifier], 13, "chartexchange_yahoo_corroborated_otc_prices")
    returns.to_parquet(ROOT / "recovered_returns.parquet")
    codes.to_parquet(ROOT / "recovered_codes.parquet")
    cutoffs.to_csv(ROOT / "combined_cutoffs.csv", index=False)
    pd.DataFrame(additions).to_csv(ROOT / "recovery_additions.csv", index=False)
    pd.DataFrame(changes).to_csv(ROOT / "recovery_corrections.csv", index=False)
    pd.DataFrame(yahoo_report).to_csv(ROOT / "yahoo_bridge.csv", index=False)
    gaps = []
    for identifier in returns:
        observed = returns[identifier].dropna()
        cutoff = cutoffs.loc[cutoffs.permno.eq(identifier)]
        end = cutoff.iloc[0].exclude_from if not cutoff.empty else "9999-12-31"
        missing = returns[identifier].isna() & (returns.index < end)
        gaps.append({"permno": identifier, "ticker": mapping.loc[identifier, "ticker"], "observations": len(observed), "expected_period_missing": int(missing.sum()), "last_observed": observed.index.max() if len(observed) else "", "exclude_from": end if not cutoff.empty else ""})
    pd.DataFrame(gaps).to_csv(ROOT / "remaining_gaps.csv", index=False)
    print(json.dumps({"observations": int(returns.notna().sum().sum()), "added": sum(row["added"] for row in additions), "removed": len(changes), "final_day": int(returns.iloc[-1].notna().sum()), "cutoffs": len(cutoffs)}, indent=2))

if __name__ == "__main__":
    main()
