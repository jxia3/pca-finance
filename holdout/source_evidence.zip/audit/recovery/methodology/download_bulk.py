import hashlib
import json
from pathlib import Path
import time
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
URL = "https://www.dolthub.com/csv/post-no-preference/stocks/master"

def main() -> None:
    destination = ROOT / "dolt_stocks.zip"
    partial = destination.with_suffix(".zip.part")
    started = time.monotonic()
    digest = hashlib.sha256()
    size = 0
    reported = started
    request = urllib.request.Request(URL, headers={"User-Agent": "public-data-research/1.0"})
    with urllib.request.urlopen(request, timeout=120) as response, partial.open("wb") as output:
        metadata = {"url": URL, "resolved_url": response.url, "headers": dict(response.headers)}
        while chunk := response.read(1024 * 1024):
            output.write(chunk)
            digest.update(chunk)
            size += len(chunk)
            if time.monotonic() - reported > 20:
                print(f"Downloaded {size / 1e6:.1f} MB in {time.monotonic() - started:.0f}s", flush=True)
                reported = time.monotonic()
    with zipfile.ZipFile(partial) as archive:
        if any(not entry.is_dir() and not entry.filename.endswith(".csv") for entry in archive.infolist()):
            raise ValueError("Unexpected non-CSV archive member")
        if archive.testzip() is not None:
            raise ValueError("Corrupt archive")
        metadata["members"] = [{"name": item.filename, "bytes": item.file_size} for item in archive.infolist()]
    metadata.update(bytes=size, sha256=digest.hexdigest())
    partial.replace(destination)
    (ROOT / "dolt_download.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2), flush=True)

if __name__ == "__main__":
    main()
