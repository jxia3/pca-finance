import json
from pathlib import Path
import pandas as pd
from review_candidates import read_table

ROOT = Path(__file__).resolve().parent

def main() -> None:
    original = pd.read_csv(ROOT.parent / "materials/daily_returns.csv", index_col="date").loc["2022-01-01":]
    calendar = pd.read_csv(ROOT.parent / "holdout/holdout_daily_returns.csv", index_col="date").index
    candidates = pd.DataFrame(index=calendar)
    reports = []
    for identifier, ticker in [("10661", "CYAN"), ("10886", "DXYN")]:
        result = json.loads((ROOT / "yahoo" / f"{ticker}.json").read_bytes())["chart"]["result"][0]
        assert not result.get("events", {})
        dates = pd.to_datetime(result["timestamp"], unit="s", utc=True).tz_convert("America/New_York").strftime("%Y-%m-%d")
        yahoo = pd.Series(result["indicators"]["quote"][0]["close"], index=dates)
        history = yahoo.reindex(original.index)
        lower = (history - 0.00501) / (history.shift(1) + 0.00501) - 1
        upper = (history + 0.00501) / (history.shift(1) - 0.00501) - 1
        paired = lower.notna() & upper.notna() & original[identifier].notna()
        agreement = original.loc[paired, identifier].between(lower[paired], upper[paired]).mean()
        assert paired.sum() >= 490 and agreement >= 0.98
        table = read_table(ticker).close.reindex(calendar)
        matched = table.sub(yahoo.reindex(calendar)).abs().le(0.00501)
        candidate = table.pct_change(fill_method=None)
        candidate = candidate.where(matched & matched.shift(1, fill_value=False) & candidate.abs().le(0.5))
        candidates[identifier] = candidate
        reports.append({"permno": identifier, "ticker": ticker, "original_pairs": int(paired.sum()), "within_cent_rounding_bounds": float(agreement), "corroborated_candidate_returns": int(candidate.notna().sum()), "rule": "Both consecutive closing prices agree between Quiver and Yahoo within half a cent; no Yahoo distribution or split events. This is a reviewed rounding exception, not the five-basis-point automatic screen."})
    candidates.to_parquet(ROOT / "otc_candidates.parquet")
    (ROOT / "otc_review.json").write_text(json.dumps(reports, indent=2), encoding="utf-8")
    print(json.dumps(reports, indent=2))

if __name__ == "__main__":
    main()
