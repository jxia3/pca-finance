import json
from pathlib import Path
import pandas as pd
from fetch_notices import fetch

ROOT = Path(__file__).resolve().parent

def main() -> None:
    prices = pd.concat([
        pd.read_parquet(ROOT / "dolt_ohlcv.parquet"),
        pd.read_parquet(ROOT / "dolt_tail.parquet"),
    ]).drop_duplicates(["date", "act_symbol"], keep="last")
    calendar = pd.read_csv(ROOT.parent / "holdout/holdout_daily_returns.csv", index_col="date").index
    candidates = pd.DataFrame(index=calendar)
    reports = []
    sources = {
        "PTN": "https://www.sec.gov/Archives/edgar/data/911216/000149315226044572/form10-k.htm",
        "SENEA": "https://www.senecafoods.com/press-release/seneca-foods-announces-shareholder-approval-of-five-for-one-forward-stock-split",
    }
    for identifier, ticker in [("79702", "PTN"), ("82279", "SENEA")]:
        result = json.loads((ROOT / "yahoo" / f"{ticker}.json").read_bytes())["chart"]["result"][0]
        dates = pd.to_datetime(result["timestamp"], unit="s", utc=True).tz_convert("America/New_York").strftime("%Y-%m-%d")
        yahoo = pd.Series(result["indicators"]["quote"][0]["close"], index=dates).reindex(calendar)
        dolt = prices.loc[prices.act_symbol.eq(ticker)].set_index("date").close.astype(float).reindex(calendar)
        if ticker == "PTN":
            # The SEC documents relisting on November 12, 2025. The OTC gap
            # is not bridged, and an unrelated later PTNT symbol is excluded.
            matched = dolt.sub(yahoo).abs().le(0.00501)
            accepted = matched & matched.shift(1, fill_value=False) & (calendar >= "2025-11-13")
            candidate = dolt.pct_change(fill_method=None).where(accepted)
            candidate = candidate.where(candidate.abs().le(0.5))
        else:
            # November 17 is the first trading day after a five-for-one split.
            matched = dolt.div(5).sub(yahoo).abs().le(0.00501)
            assert matched.loc["2026-10-20":"2026-11-16"].all()
            candidate = pd.Series(float("nan"), index=calendar)
            candidate.loc["2026-11-17"] = result["meta"]["regularMarketPrice"] * 5 / dolt.loc["2026-11-16"] - 1
        assert candidate.dropna().between(-1, 0.5).all()
        candidates[identifier] = candidate
        reports.append({"permno": identifier, "ticker": ticker, "candidate_count": int(candidate.notna().sum()), "source": sources[ticker], "notice": fetch(sources[ticker])})
    candidates.to_parquet(ROOT / "action_candidates.parquet")
    (ROOT / "action_review.json").write_text(json.dumps(reports, indent=2), encoding="utf-8")
    print(candidates.count().to_string())

if __name__ == "__main__":
    main()
