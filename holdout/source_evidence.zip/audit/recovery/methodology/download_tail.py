from concurrent.futures import ThreadPoolExecutor
import io
import json
from pathlib import Path
import time
import urllib.parse
import urllib.request
import zipfile
import pandas as pd

ROOT = Path(__file__).resolve().parent

def fetch(arguments: tuple[str, list[str], int]) -> dict:
    date, symbols, batch = arguments
    path = ROOT / "tail" / f"{date}_{batch:02d}.json"
    if path.exists():
        return json.loads(path.read_text())
    quoted = ",".join("'" + symbol.replace("'", "''") + "'" for symbol in symbols)
    query = f"SELECT * FROM ohlcv WHERE date = '{date}' AND act_symbol IN ({quoted}) LIMIT 1000"
    url = "https://www.dolthub.com/api/v1alpha1/post-no-preference/stocks/master?q=" + urllib.parse.quote(query)
    for attempt in range(3):
        try:
            with urllib.request.urlopen(url, timeout=90) as response:
                result = json.load(response)
            if result.get("query_execution_status") != "Success":
                raise ValueError(str(result)[:200])
            result["source_url"] = url
            path.write_text(json.dumps(result), encoding="utf-8")
            print(date, batch, len(result["rows"]), flush=True)
            return result
        except Exception:
            if attempt == 2:
                raise
            time.sleep(2)
    raise RuntimeError("Unreachable")

def main() -> None:
    (ROOT / "tail").mkdir(exist_ok=True)
    mapping = pd.read_csv(ROOT.parent / "holdout/holdout_tickers.csv")
    symbols = sorted(set(mapping.ticker) | {"BPPTU", "PTNT", "PTNTD", "SALMZ", "TUPBQ"})
    dates = pd.bdate_range("2026-11-10", "2026-11-17").strftime("%Y-%m-%d")
    tasks = [(date, symbols[start:start + 400], start // 400) for date in dates for start in range(0, len(symbols), 400)]
    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(fetch, tasks))
    frame = pd.DataFrame([row for result in results for row in result["rows"]])
    frame.to_parquet(ROOT / "dolt_tail.parquet", index=False)
    print(frame.groupby("date").size().to_string(), flush=True)

if __name__ == "__main__":
    main()
