import json
from pathlib import Path
import numpy as np
import pandas as pd
from screen_bulk import metrics

ROOT = Path(__file__).resolve().parent

def main() -> None:
    mapping = pd.read_csv(ROOT.parent / "holdout/holdout_tickers.csv", dtype=str).set_index("stock_id")
    original = pd.read_csv(ROOT.parent / "materials/daily_returns.csv", index_col="date").loc["2022-01-01":]
    prices = pd.concat([pd.read_parquet(ROOT / "dolt_ohlcv.parquet"), pd.read_parquet(ROOT / "dolt_tail.parquet")]).drop_duplicates(["date", "act_symbol"], keep="last")
    screen = pd.read_csv(ROOT / "bulk_screen.csv", dtype={"permno": str}).set_index("permno")
    candidates = {}
    reports = []
    for identifier, row in mapping.iterrows():
        path = ROOT / "yahoo" / f"{row.ticker}.json"
        if not path.exists():
            continue
        result = json.loads(path.read_bytes())["chart"]["result"][0]
        dates = pd.to_datetime(result["timestamp"], unit="s", utc=True).tz_convert("America/New_York").strftime("%Y-%m-%d")
        adjusted = pd.Series(result["indicators"]["adjclose"][0]["adjclose"], index=dates, dtype=float)
        candidate = adjusted.pct_change(fill_method=None)
        score = metrics(original[identifier], candidate)
        candidates[identifier] = candidate
        meta = result["meta"]
        quote_date = pd.Timestamp(meta["regularMarketTime"], unit="s", tz="UTC").tz_convert("America/New_York").strftime("%Y-%m-%d")
        dolt = prices.loc[prices.act_symbol.eq(row.ticker)].set_index("date").close.astype(float).sort_index()
        yahoo = pd.Series(result["indicators"]["quote"][0]["close"], index=dates, dtype=float)
        close_pairs = pd.concat([dolt.rename("dolt"), yahoo.rename("yahoo")], axis=1).loc["2026-10-20":"2026-11-16"].dropna()
        price_error = (close_pairs.dolt - close_pairs.yahoo).abs()
        verified_history = identifier in screen.index and screen.loc[identifier, "pairs"] >= 100 and screen.loc[identifier, "correlation"] >= 0.995 and screen.loc[identifier, "within_5bp"] >= 0.95
        if identifier == "80168":
            verified_history = screen.loc[identifier, "status"] == "pass"
        if identifier == "84781":
            verified_history = screen.loc[identifier, "status"] == "pass"
        dividends = result.get("events", {}).get("dividends", {})
        cash = sum(event["amount"] for event in dividends.values() if pd.Timestamp(event["date"], unit="s", tz="UTC").tz_convert("America/New_York").strftime("%Y-%m-%d") == "2026-11-17")
        split_today = any(pd.Timestamp(event["date"], unit="s", tz="UTC").tz_convert("America/New_York").strftime("%Y-%m-%d") == "2026-11-17" for event in result.get("events", {}).get("splits", {}).values())
        accepted = verified_history and quote_date == "2026-11-17" and len(close_pairs) >= 10 and price_error.max() <= 0.00501 and "2026-11-16" in dolt.index and not split_today
        latest = (meta["regularMarketPrice"] + cash) / dolt.get("2026-11-16", np.nan) - 1 if accepted else np.nan
        if abs(latest) > 0.5:
            accepted = False
            latest = np.nan
        reports.append({"permno": identifier, "ticker": row.ticker, "quote_date": quote_date, "price_pairs": len(close_pairs), "max_close_rounding_error": price_error.max(), "quote_close": meta["regularMarketPrice"], "previous_dolt_close": dolt.get("2026-11-16"), "cash": cash, "accepted": accepted, "latest_return": latest, **score})
    pd.DataFrame(candidates).to_parquet(ROOT / "yahoo_candidates.parquet")
    report = pd.DataFrame(reports)
    report.to_csv(ROOT / "latest_checks.csv", index=False)
    print(report.groupby("accepted").size().to_string())
    print(report.loc[~report.accepted, ["ticker", "quote_date", "price_pairs", "max_close_rounding_error", "pairs", "within_5bp"]].to_string(index=False))

if __name__ == "__main__":
    main()
