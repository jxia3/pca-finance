import io
from pathlib import Path
import zipfile
import pandas as pd

ROOT = Path(__file__).resolve().parent

def main() -> None:
    with zipfile.ZipFile(ROOT.parent / "holdout/source_evidence.zip") as evidence:
        mapping = pd.read_csv(io.BytesIO(evidence.read("audit/mapping.csv")), dtype=str)
        transitions = pd.read_csv(io.BytesIO(evidence.read("raw/returns_extension/bulk_research/reviewed_symbol_transitions.csv")), dtype=str)
    symbols = set(mapping.ticker) | set(transitions.old_symbol)
    symbols.update(["BPPTU", "PTNT", "PTNTD", "TUP", "SALM", "SALMZ", "SUP", "SUPR", "SGMA", "SGMAQ", "DXYN", "DYNT", "DYNTQ"])
    for name in ["dividend", "ohlcv", "split"]:
        with (ROOT / f"{name}.csv").open("rb") as source:
            header = pd.read_csv(source, nrows=0).columns
        print(name, list(header), flush=True)
        if "act_symbol" not in header:
            continue
        parts = []
        count = 0
        with (ROOT / f"{name}.csv").open("rb") as source:
            for frame in pd.read_csv(source, chunksize=500_000, dtype=str):
                count += len(frame)
                selected = frame.act_symbol.isin(symbols)
                date_column = next((column for column in ["date", "ex_date"] if column in frame), None)
                if date_column:
                    selected &= frame[date_column].between("2022-01-01", "2026-11-17")
                parts.append(frame.loc[selected])
        result = pd.concat(parts, ignore_index=True)
        result.to_parquet(ROOT / f"dolt_{name}.parquet", index=False)
        print(f"{name}: scanned {count:,}; retained {len(result):,}", flush=True)

if __name__ == "__main__":
    main()
