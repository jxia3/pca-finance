from concurrent.futures import ThreadPoolExecutor
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parent

def fetch(url: str) -> dict:
    name = hashlib.sha256(url.encode()).hexdigest()[:16]
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 public academic research"})
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            contents = response.read(20_000_001)
            if len(contents) > 20_000_000:
                raise ValueError("Oversized notice")
            content_type = response.headers.get("Content-Type", "")
            if not any(kind in content_type for kind in ["text/", "application/pdf", "application/xhtml"]):
                raise ValueError(f"Unexpected notice type: {content_type}")
        suffix = ".pdf" if contents.startswith(b"%PDF") else ".html"
        path = ROOT / "notices" / (name + suffix)
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(contents)
        challenge = b"challenge" in contents.lower() and len(contents) < 20000
        return {"url": url, "file": path.name, "bytes": len(contents), "sha256": hashlib.sha256(contents).hexdigest(), "retrieved_utc": datetime.now(timezone.utc).isoformat(), "requires_browser_verification": challenge}
    except Exception as error:
        return {"url": url, "error": str(error)}

def main() -> None:
    with (ROOT / "reviewed_cutoffs.csv").open() as file:
        urls = sorted({row["source"] for row in csv.DictReader(file)})
    manifest_path = ROOT / "notice_manifest.json"
    previous = json.loads(manifest_path.read_bytes()) if manifest_path.exists() else []
    retained = {entry["url"]: entry for entry in previous if "file" in entry}
    missing = [url for url in urls if url not in retained]
    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(retained.values()) + list(executor.map(fetch, missing))
    (ROOT / "notice_manifest.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()
