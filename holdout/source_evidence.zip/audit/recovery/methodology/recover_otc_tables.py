import hashlib
import json
from pathlib import Path
import re
import urllib.request
import pandas as pd
from fetch_notices import fetch
from fetch_tables import TableParser

ROOT = Path(__file__).resolve().parent

def main() -> None:
    calendar = pd.read_parquet(ROOT / "recovered_returns.parquet").index
    original = pd.read_csv(ROOT.parent / "materials/daily_returns.csv", index_col="date").loc["2022-01-01":]
    candidates = pd.DataFrame(index=calendar)
    reports = []
    directory = ROOT / "otc_tables"
    directory.mkdir(exist_ok=True)
    for identifier, ticker in [("10661", "CYAN"), ("10886", "DXYN"), ("46340", "SFES")]:
        url = f"https://chartexchange.com/symbol/otc-{ticker.lower()}/historical/"
        path = directory / f"{ticker}.html"
        if not path.exists():
            request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=40) as response:
                contents = response.read(3_000_001)
                assert len(contents) < 3_000_000
            path.write_bytes(contents)
        parser = TableParser()
        parser.feed(path.read_text(encoding="utf-8"))
        rows = [row for row in parser.rows if len(row) == 8 and re.fullmatch(r"202[456]-\d\d-\d\d", row[0])]
        table = pd.DataFrame(rows, columns=["date", "open", "high", "low", "close", "change", "volume", "change_since"])
        table.to_csv(directory / f"{ticker}.csv", index=False)
        close = table.set_index("date").close.astype(float).reindex(calendar)
        result = json.loads((ROOT / "yahoo" / f"{ticker}.json").read_bytes())["chart"]["result"][0]
        assert not result.get("events", {}).get("splits")
        dates = pd.to_datetime(result["timestamp"], unit="s", utc=True).tz_convert("America/New_York").strftime("%Y-%m-%d")
        yahoo = pd.Series(result["indicators"]["quote"][0]["close"], index=dates)
        cash = pd.Series(0.0, index=original.index.union(calendar))
        for event in result.get("events", {}).get("dividends", {}).values():
            date = pd.Timestamp(event["date"], unit="s", tz="UTC").tz_convert("America/New_York").strftime("%Y-%m-%d")
            cash.loc[date] = event["amount"]
        history = yahoo.reindex(original.index)
        lower = (history - 0.00501 + cash.reindex(original.index)) / (history.shift(1) + 0.00501) - 1
        upper = (history + 0.00501 + cash.reindex(original.index)) / (history.shift(1) - 0.00501) - 1
        pairs = lower.notna() & original[identifier].notna()
        agreement = original.loc[pairs, identifier].between(lower[pairs], upper[pairs]).mean()
        assert pairs.sum() == 500 and agreement >= 0.98
        matched = close.sub(yahoo.reindex(calendar)).abs().le(0.00501)
        candidate = (close + cash.reindex(calendar)) / close.shift(1) - 1
        candidate = candidate.where(matched & matched.shift(1, fill_value=False) & candidate.abs().le(0.5))
        candidates[identifier] = candidate
        reports.append({"permno": identifier, "ticker": ticker, "url": url, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "rows": len(table), "original_pairs": int(pairs.sum()), "original_rounding_agreement": float(agreement), "corroborated_candidates": int(candidate.notna().sum())})
    sources = [
        "https://www.sec.gov/Archives/edgar/data/86115/000143774924003695/sfe20240212_8k.htm",
        "https://www.otcmarkets.com/news-otcapi/news/document/content/id?id=89705",
    ]
    notices = [fetch(url) for url in sources]
    (ROOT / "otc_table_review.json").write_text(json.dumps({"tables": reports, "notices": notices}, indent=2), encoding="utf-8")
    candidates.to_parquet(ROOT / "otc_table_candidates.parquet")
    print(json.dumps(reports, indent=2))

if __name__ == "__main__":
    main()
