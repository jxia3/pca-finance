import hashlib
import json
from pathlib import Path
import struct
import urllib.request
import zlib
import pandas as pd
from extract_bulk import ROOT

def main() -> None:
    path = ROOT / "dolt_stocks.zip.part"
    data = path.read_bytes()
    position = 0
    records = []
    while data[position:position + 4] == b"PK\x03\x04":
        header = struct.unpack("<4s5H3I2H", data[position:position + 30])
        name = data[position + 30:position + 30 + header[-2]].decode()
        assert name in {"dividend.csv", "dolt_docs.csv", "ohlcv.csv", "split.csv", "symbol.csv"}
        offset = position + 30 + header[-2] + header[-1]
        decompressor = zlib.decompressobj(-15)
        output_path = ROOT / name
        with output_path.open("wb") as output:
            while offset < len(data) and not decompressor.eof:
                end = min(offset + 1048576, len(data))
                output.write(decompressor.decompress(data[offset:end]))
                offset = end
        if not decompressor.eof:
            with output_path.open("r+b") as output:
                output.seek(max(0, output_path.stat().st_size - 1000))
                tail_start = output.tell()
                tail = output.read()
                output.truncate(tail_start + tail.rfind(b"\n") + 1)
        with output_path.open("rb") as output:
            checksum = hashlib.file_digest(output, "sha256").hexdigest()
        records.append({"file": name, "complete_member": decompressor.eof, "bytes": output_path.stat().st_size, "sha256": checksum})
        print(records[-1], flush=True)
        position = offset - len(decompressor.unused_data) + 16
    metadata = {"url": "https://www.dolthub.com/csv/post-no-preference/stocks/master", "status": "connection_closed_incomplete_zip", "partial_zip_sha256": hashlib.sha256(data).hexdigest(), "partial_zip_bytes": len(data), "recovered_members": records}
    (ROOT / "dolt_download.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    for name in ["split", "symbol"]:
        url = f"https://www.dolthub.com/csv/post-no-preference/stocks/master/{name}"
        with urllib.request.urlopen(url, timeout=120) as response:
            contents = response.read()
        (ROOT / f"{name}.csv").write_bytes(contents)
        print(name, len(contents), flush=True)

if __name__ == "__main__":
    main()
