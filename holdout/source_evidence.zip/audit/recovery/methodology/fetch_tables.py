from concurrent.futures import ThreadPoolExecutor
from html.parser import HTMLParser
import json
from pathlib import Path
import urllib.request
import pandas as pd

ROOT = Path(__file__).resolve().parent

class TableParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.rows = []
        self.row = []
        self.cell = None

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag == "tr":
            self.row = []
        if tag in ["td", "th"]:
            self.cell = []

    def handle_data(self, value: str) -> None:
        if self.cell is not None:
            self.cell.append(value)

    def handle_endtag(self, tag: str) -> None:
        if tag in ["td", "th"] and self.cell is not None:
            self.row.append(" ".join("".join(self.cell).split()))
            self.cell = None
        if tag == "tr" and self.row:
            self.rows.append(self.row)

def fetch(symbol: str) -> dict:
    url = f"https://www.quiverquant.com/stock/{symbol}/historical-prices/"
    path = ROOT / "tables" / f"{symbol}.html"
    try:
        if not path.exists():
            request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=40) as response:
                path.write_bytes(response.read())
        parser = TableParser()
        parser.feed(path.read_text(encoding="utf-8"))
        rows = [row for row in parser.rows if len(row) == 7 and row[0][:3] in ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]]
        frame = pd.DataFrame(rows, columns=["date", "open", "high", "low", "close", "adjusted_close", "volume"])
        frame.to_csv(ROOT / "tables" / f"{symbol}.csv", index=False)
        return {"symbol": symbol, "url": url, "rows": len(frame)}
    except Exception as error:
        return {"symbol": symbol, "url": url, "error": str(error)}

def main() -> None:
    (ROOT / "tables").mkdir(exist_ok=True)
    symbols = ["SUP", "SGMA", "STRM", "SCS", "ALOT", "CYAN", "DXYN", "AKO-A", "AGM-A", "MXE", "BRKL", "SENEA", "ACH", "SKM"]
    with ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(fetch, symbols))
    (ROOT / "table_manifest.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    main()
