import json
from pathlib import Path
import pandas as pd
from review_candidates import read_table
from screen_bulk import metrics

ROOT = Path(__file__).resolve().parent

def main() -> None:
    baseline = pd.read_parquet(ROOT / "recovered_returns.parquet")
    codes = pd.read_parquet(ROOT / "recovered_codes.parquet")
    reference = baseline.where(~codes.isin([3, 12, 13]))
    mapping = pd.read_csv(ROOT.parent / "holdout/holdout_tickers.csv", dtype=str).set_index("stock_id")
    screen = pd.read_csv(ROOT / "bulk_screen.csv", dtype={"permno": str}).set_index("permno")
    dividends = pd.read_parquet(ROOT / "dolt_dividend.parquet")
    splits = pd.read_parquet(ROOT / "dolt_split.parquet")
    candidates = pd.DataFrame(index=baseline.index)
    reports = []
    for identifier, row in mapping.iterrows():
        ticker = row.ticker
        path = ROOT / "tables" / f"{ticker.replace('.', '-')}.csv"
        if not path.exists() or identifier not in screen.index:
            continue
        table = read_table(ticker.replace(".", "-"))
        if len(table) < 100:
            continue
        # Mixed adjusted/unadjusted bases need separate action review.
        actions = splits.loc[splits.act_symbol.eq(ticker) & splits.ex_date.ge(table.index.min())]
        if len(actions) or ticker in ["PTN", "SENEA", "SKM", "AKO.A", "DHY", "TY"]:
            continue
        close = table.close.reindex(baseline.index)
        cash = dividends.loc[dividends.act_symbol.eq(ticker)].set_index("ex_date").amount.astype(float)
        candidate = (close + cash.reindex(baseline.index, fill_value=0)) / close.shift(1) - 1
        score = metrics(reference[identifier], candidate)
        historical = screen.loc[identifier]
        identity = historical.pairs >= 100 and historical.correlation >= 0.995 and historical.within_5bp >= 0.95
        accepted = identity and score["pairs"] >= 100 and score["max_error"] <= 0.0005
        candidate = candidate.where(candidate.abs().le(0.5))
        if accepted:
            candidates[identifier] = candidate
        reports.append({"permno": identifier, "ticker": ticker, "accepted": accepted, "new_available": int((baseline[identifier].isna() & candidate.notna()).sum()), **score})
    candidates.to_parquet(ROOT / "table_candidates.parquet")
    report = pd.DataFrame(reports)
    report.to_csv(ROOT / "table_screen.csv", index=False)
    print(report.loc[report.new_available.gt(0)].to_string(index=False))

if __name__ == "__main__":
    main()
