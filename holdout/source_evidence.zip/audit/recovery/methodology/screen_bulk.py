import io
import json
from pathlib import Path
import zipfile
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
PREFIX = "raw/returns_extension/bulk_research/"

def metrics(reference: pd.Series, candidate: pd.Series) -> dict:
    pairs = pd.concat([reference.rename("reference"), candidate.rename("candidate")], axis=1).dropna()
    errors = (pairs.reference - pairs.candidate).abs()
    return {"pairs": len(pairs), "correlation": pairs.reference.corr(pairs.candidate), "within_5bp": errors.le(0.0005).mean(), "max_error": errors.max()}

def main() -> None:
    with zipfile.ZipFile(ROOT.parent / "holdout/source_evidence.zip") as archive:
        def table(name: str) -> pd.DataFrame:
            return pd.read_csv(io.BytesIO(archive.read(name)), dtype=str)

        def document(name: str) -> dict:
            return json.loads(archive.read(PREFIX + name))

        mapping = table("audit/mapping.csv")
        cutoffs = table("audit/reviewed_security_cutoffs.csv").set_index("permno")
        transitions = table(PREFIX + "reviewed_symbol_transitions.csv").set_index("permno")
        split_policy = document("reviewed_dolt_split_policy.json")
        boundaries = document("dolt_panel/temporary_review_boundaries.json")
        supplements = document("reviewed_distribution_supplements.json")
        dividends_other = pd.read_parquet(io.BytesIO(archive.read(PREFIX + "defeatbeta_stock_dividend_events.parquet")))
        bny = table("raw/returns_extension/akoa_bny_gross_dated_events.csv")
    new_cutoffs = pd.read_csv(ROOT / "reviewed_cutoffs.csv", dtype=str).set_index("permno")
    cutoffs = pd.concat([cutoffs, new_cutoffs])
    assert cutoffs.index.is_unique
    original = pd.read_csv(ROOT.parent / "materials/daily_returns.csv", index_col="date").loc["2022-01-01":]
    prior = pd.read_csv(ROOT.parent / "holdout/holdout_daily_returns.csv", index_col="date")
    calendar = original.index.union(prior.index).sort_values()
    prices = pd.read_parquet(ROOT / "dolt_ohlcv.parquet")
    tail = pd.read_parquet(ROOT / "dolt_tail.parquet")
    common = prices.merge(tail, on=["date", "act_symbol"], suffixes=("_bulk", "_tail"))
    assert (common.close_bulk.astype(float) == common.close_tail.astype(float)).all()
    prices = pd.concat([prices, tail], ignore_index=True).drop_duplicates(["date", "act_symbol"], keep="last")
    dividends = pd.read_parquet(ROOT / "dolt_dividend.parquet")
    splits = pd.read_parquet(ROOT / "dolt_split.parquet")
    candidates = {}
    reports = []
    for row in mapping.itertuples():
        if prior[row.permno].notna().all():
            continue

        def select(frame: pd.DataFrame, date_column: str) -> pd.DataFrame:
            selected = frame.act_symbol.eq(row.ticker)
            if row.permno in transitions.index:
                transition = transitions.loc[row.permno]
                selected = (selected & frame[date_column].ge(transition.new_symbol_start)) | (frame.act_symbol.eq(transition.old_symbol) & frame[date_column].lt(transition.new_symbol_start))
            if row.permno in cutoffs.index:
                selected &= frame[date_column].lt(cutoffs.loc[row.permno, "exclude_from"])
            return frame.loc[selected].copy()

        selected_prices = select(prices, "date")
        if selected_prices.empty:
            reports.append({"permno": row.permno, "ticker": row.ticker, "status": "no_prices"})
            continue
        assert not selected_prices.date.duplicated().any(), row.ticker
        close = selected_prices.set_index("date").close.astype(float).reindex(calendar)
        events = select(dividends, "ex_date").set_index("ex_date").amount.astype(float)
        if row.permno == "84660":
            official = bny.set_index("ex_date").gross_distribution.astype(float)
            events = pd.concat([events[~events.index.isin(official.index)], official])
        if row.ticker in supplements["symbols"]:
            extra = dividends_other.loc[dividends_other.symbol.eq(row.ticker)].set_index("report_date").amount.astype(float)
            events = pd.concat([events, extra[~extra.index.isin(events.index)]])
        assert events.index.is_unique, row.ticker
        factors = pd.Series(1.0, index=calendar)
        policy = split_policy.get(row.permno, {})
        for date, ratio in policy.get("events", {}).items():
            if date in factors.index:
                factors.loc[date] = ratio
        returns = (close * factors + events.reindex(calendar, fill_value=0)) / close.shift(1) - 1
        score = metrics(original[row.permno], returns)
        passed = score["pairs"] >= 100 and score["correlation"] >= 0.995 and score["within_5bp"] >= 0.95
        if row.permno == "80168":
            passed = score["pairs"] >= 78 and score["correlation"] >= 0.99999 and score["max_error"] <= 0.00001
        if row.permno == "84781":
            corrected = metrics(original[row.permno].drop("2022-12-15"), returns.drop("2022-12-15"))
            passed = corrected["pairs"] >= 499 and corrected["correlation"] >= 0.995 and corrected["within_5bp"] == 1
        status = "pass" if passed else "original_overlap_review"
        actions = select(splits, "ex_date")
        unreviewed = actions.loc[~actions.ex_date.isin(list(policy.get("events", {})) + policy.get("ignored_vendor_dates", []))]
        if len(unreviewed):
            status = "split_review"
        candidate = returns.reindex(prior.index)
        if row.permno in boundaries:
            candidate.loc[candidate.index >= boundaries[row.permno]["exclude_from"]] = np.nan
        bridge = metrics(prior[row.permno], candidate)
        if bridge["pairs"] and bridge["max_error"] > 0.0005:
            status = "bridge_review"
        additions = candidate.where(prior[row.permno].isna())
        if additions.abs().gt(0.5).any():
            status = "large_return_review"
        if row.ticker in ["SKM", "DHY", "TY"]:
            status = "distribution_review"
        if np.isinf(candidate).any() or candidate.lt(-1).any():
            status = "invalid_return_review"
        candidates[row.permno] = candidate
        reports.append({"permno": row.permno, "ticker": row.ticker, "status": status, "new_available": int(additions.notna().sum()), "last_price": selected_prices.date.max(), "unreviewed_splits": len(unreviewed), "bridge_pairs": bridge["pairs"], "bridge_max_error": bridge["max_error"], **score})
    report = pd.DataFrame(reports)
    report.to_csv(ROOT / "bulk_screen.csv", index=False)
    pd.DataFrame(candidates).to_parquet(ROOT / "bulk_candidates.parquet")
    print(report.groupby("status").agg(stocks=("permno", "size"), additions=("new_available", "sum")).to_string())

if __name__ == "__main__":
    main()
